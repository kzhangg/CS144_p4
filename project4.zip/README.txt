================
Easy deployment:
================

chmod 777 deploy.sh
./deploy.sh